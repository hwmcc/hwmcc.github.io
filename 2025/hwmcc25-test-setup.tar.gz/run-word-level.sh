#!/bin/bash

BENCHMARK="$1"
shift
TOOL="$@"
CERT_SAT="certificate.sat"

[ -z "$BENCHMARK" ] && echo "run-word-level.sh <benchmark> <tool...>" && exit 1

out=$($TOOL $BENCHMARK $CERT_SAT)

if [[ $out == "sat" ]]; then
  if [ ! -f "certificate.sat" ]; then
    echo "sat output, but no sat certificate found in $(pwd)."
    exit 1
  fi
elif [[ $out == "unsat" ]]; then
  : # ok, no unsat certificate required
else
  echo "invalid output. expected sat/unsat answer, got '$out' instead."
  exit 1
fi
