#!/bin/bash
dir="$(cd -- "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd -P)"

BENCHMARK="$1"
shift
TOOL="$@"
CERT_SAT="sat.aig_trace"
CERT_UNSAT="unsat.aig"

[ -z "$BENCHMARK" ] && echo "run-bit-level.sh <benchmark> <tool...>" && exit 1

if [ -n "$LIVENESS_TRACK" ]; then
  out=$($TOOL $BENCHMARK $CERT_SAT)
else
  out=$($TOOL $BENCHMARK $CERT_SAT $CERT_UNSAT)
fi
echo "$out"

if grep -q '^sat$' <<<"$out"; then
  if [ ! -f "$CERT_SAT" ]; then
    echo "sat output, but no sat certificate found in $(pwd)."
    exit 1
  fi
  if ! "$dir"/certify-bit-level/check_sat "$BENCHMARK" "$CERT_SAT"; then
    echo "sat certificate is invalid."
    exit 1
  fi
elif grep -q '^unsat$' <<<"$out"; then
  if [ ! -f "$CERT_UNSAT" ]; then
    if [ -n "$LIVENESS_TRACK" ]; then
      exit 0
    fi
    echo "unsat output, but no unsat certificate found in $(pwd)."
    exit 1
  fi
  if ! "$dir"/certify-bit-level/check_unsat "$BENCHMARK" "$CERT_UNSAT"; then
    echo "unsat certificate is invalid."
    exit 1
  fi
else
  echo "invalid output. expected sat/unsat as a single line in model checker output"
  exit 1
fi
