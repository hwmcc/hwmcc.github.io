# HWMCC'25 Submission Test Setup

1. Build docker image

    ```
    docker build .  -t hwmcc25
    ```

2. Copy your solver binaries/files to some directory `<solver-dir>`.

3. Start docker image

    ```
    docker run --rm -v absolute/path/to/<solver-dir>:/home/hwmcc/submission --privileged --cap-drop=all -it hwmcc25:latest
    ```

    Note: It is assumed that your machine has cgroups v2 set up (i.e.,
    `/sys/fs/cgroup/` exists). `--privileged` is required for runexec to have
    access to the cgroups filesystem of the host machine.

4. Execute your solver

    ```
    ./run.sh <benchmark> $(pwd)/submission/<binary>

    ./run-live.sh <benchmark> $(pwd)/submission/<binary>   # for liveness bit-level track
    ```
    Note: Make sure that the path to your solver binary is an absolute path.
    The docker image includes sat and unsat example benchmarks for the
    bit-level and word-level track.

    The output of your solver will be in `test_job/output.log` and will be
    printed to stdout. The `run-*.sh` scripts calls your solver via the
    required command line interface and checks for the expected outputs
    sat/unsat and if the corresponding certificate files exist.
    `run.sh` resembles the execution of runexec with the options used for the
    competition. These files should not be modified by participants to make
    their submission work.
    
5. Fuzz your solver

    ```
    ./certify-bit-level/certifuzzer $(pwd)/submission/<binary>
    ```

    Fuzzing for word-level is experimental. Feel free explore the scripts.
