#!/bin/bash

export LIVENESS_TRACK=yes
./run.sh $@
