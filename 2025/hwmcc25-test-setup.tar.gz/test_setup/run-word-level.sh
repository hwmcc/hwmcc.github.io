#!/bin/bash

BENCHMARK="$1"
shift
TOOL="$@"
CERT_SAT="sat.btor2_trace"

[ -z "$BENCHMARK" ] && echo "run-word-level.sh <benchmark> <tool...>" && exit 1

out=$($TOOL $BENCHMARK $CERT_SAT)
echo "$out"

if grep -q '^sat$' <<<"$out"; then
  if [ ! -f "$CERT_SAT" ]; then
    echo "sat output, but no sat certificate found in $(pwd)."
    exit 1
  fi
  if ! "$dir"/certify-word-level/check_sat "$BENCHMARK" "$CERT_SAT"; then
    echo "sat certificate is invalid."
    exit 1
  fi
elif grep -q '^unsat$' <<<"$out"; then
  : # ok, no unsat certificate required
  # However, a prototype for a btor2 witness checker is available:
  # Uncomment this and add $CERT_UNSAT to the solver call
  # if ! "$dir"/certify-word-level/check_unsat "$BENCHMARK" "$CERT_UNSAT"; then
    # echo "unsat certificate is invalid."
    # exit 1
  # fi
else
  echo "invalid output. expected sat/unsat as a single line in model checker output"
  exit 1
fi
