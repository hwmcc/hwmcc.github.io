#!/bin/bash

BENCHMARK="$1"
shift
TOOL="$@"
TIME_LIMIT=3600
MEMORY_LIMIT=128000MB
LOGDIR="$HOME/test_job"

[ -z "$BENCHMARK" ] && echo "run.sh <benchmark> <tool...>" && exit 1

RUNSCRIPT="run-bit-level.sh"
if [[ "${BENCHMARK: -5}" == "btor2" ]]; then
  RUNSCRIPT="run-word-level.sh"
fi

BENCHMARK=$(realpath "$BENCHMARK")
RUNSCRIPT=$(realpath "$RUNSCRIPT")

rm -rf "$LOGDIR"
mkdir -p "$LOGDIR"

pushd "$LOGDIR"

echo "runexec output:"
echo "==================="
runexec \
  --timelimit=$TIME_LIMIT \
  --memlimit=$MEMORY_LIMIT \
  --read-only-dir "/" \
  --dir "$LOGDIR" \
  --full-access-dir "$LOGDIR" \
  --output "$LOGDIR/output.log" \
  -- \
  $RUNSCRIPT $BENCHMARK $TOOL

popd

echo "output.log:"
echo "==================="
cat "test_job/output.log"
