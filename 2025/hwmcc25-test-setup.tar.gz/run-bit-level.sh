#!/bin/bash

BENCHMARK="$1"
shift
TOOL="$@"
CERT_SAT="certificate.sat"
CERT_UNSAT="certificate.unsat"

[ -z "$BENCHMARK" ] && echo "run-bit-level.sh <benchmark> <tool...>" && exit 1

out=$($TOOL $BENCHMARK $CERT_SAT $CERT_UNSAT)
echo "$out"

if [[ $out == "sat" ]]; then
  if [ ! -f "certificate.sat" ]; then
    echo "sat output, but no sat certificate found in $(pwd)."
    exit 1
  fi
elif [[ $out == "unsat" ]]; then
  if [ ! -f "certificate.unsat" ]; then
    echo "unsat output, but no unsat certificate found in $(pwd)."
    exit 1
  fi
else
  echo "invalid output. expected sat/unsat answer, got '$out' instead."
  exit 1
fi
